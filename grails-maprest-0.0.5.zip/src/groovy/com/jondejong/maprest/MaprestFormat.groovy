package com.jondejong.maprest

/**
 * Created with IntelliJ IDEA.
 * User: jondejong
 * Date: 1/21/13
 * Time: 6:49 PM
 * To change this template use File | Settings | File Templates.
 */
class MaprestFormat {

    enum Format {
        XML, JSON, CLIENT_ACCEPTED
    }
}
